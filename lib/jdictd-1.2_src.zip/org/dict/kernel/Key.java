package org.dict.kernel;

public class Key implements IKey {
	private String fKey, fOffset, fLength;
	private String fComparableKey;
	static java.util.BitSet spacenum;
	static {
		initialize();
	}
/**
 * Contruct a dummy key, used for comparisons only
 */
public Key(String k, String off, String len) {
	super();
	fKey = k;
	fOffset = off;
	fLength = len;
}
protected String getComparableKey() {
	if (fComparableKey == null) {
		char[] arr = new char[fKey.length()];
		int len = 0;
		for (int i = 0; i < arr.length; i++) {
			char c = fKey.charAt(i);
			if (isspacealnum(c)) {
				arr[len++] = c;
			}
		}
		fComparableKey = new String(arr, 0, len).toLowerCase();
	}
	return fComparableKey;
}
/**
 * Insert the method's description here.
 * Creation date: (03.09.01 22:18:17)
 * @return java.lang.String
 */
public java.lang.String getKey() {
	return fKey;
}
/**
 * Insert the method's description here.
 * Creation date: (03.09.01 22:18:17)
 * @return java.lang.String
 */
public java.lang.String getLength() {
	return fLength;
}
/**
 * Insert the method's description here.
 * Creation date: (03.09.01 22:18:17)
 * @return java.lang.String
 */
public java.lang.String getOffset() {
	return fOffset;
}
static void initialize() {
	spacenum = new java.util.BitSet();
	spacenum.set(' ');
	for (int i = 0; i < 256; i++) {
		if (Character.isLetterOrDigit((char) i)) {
			spacenum.set(i);
		}
	}
}
static boolean isspacealnum(char c) {
	//return spacenum.get(c);
	return c == ' ' || Character.isLetterOrDigit(c);
}
/**
 * Insert the method's description here.
 * Creation date: (03.09.01 22:18:17)
 * @param newKey java.lang.String
 */
public void setKey(java.lang.String newKey) {
	fKey = newKey;
}
/**
 * Insert the method's description here.
 * Creation date: (03.09.01 22:18:17)
 * @param newLength java.lang.String
 */
public void setLength(java.lang.String newLength) {
	fLength = newLength;
}
/**
 * Insert the method's description here.
 * Creation date: (03.09.01 22:18:17)
 * @param newOffset java.lang.String
 */
public void setOffset(java.lang.String newOffset) {
	fOffset = newOffset;
}
public String toString() {
	return fKey;
}
}
