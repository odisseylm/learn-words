package org.dict.kernel;

import java.io.*;
/**
 * Insert the type's description here.
 * Creation date: (28.07.01 22:45:52)
 * @author: Administrator
 */
public class FlatDatabase extends Database {
/**
 * FlatDatabase constructor comment.
 */
public FlatDatabase() {
	super();
}

/**
 * readData method comment.
 */
protected byte[] readData(long pos, long len) throws IOException {
	java.io.RandomAccessFile f = null;
	byte[] buf = new byte[(int)len];
	try {
		f = new java.io.RandomAccessFile(getDatafile(), "r");
		f.seek(pos);
		f.readFully(buf);
		return buf;
	} finally {
		if (f != null) {
			f.close();
			f = null;
		}
	}
}
}
