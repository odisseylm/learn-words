package org.dict.kernel;

import java.util.Vector;
import java.util.StringTokenizer;
//import com.sun.java.util.collections.*;
import java.io.*;
/**
 * Insert the type's description here.
 * Creation date: (29.07.01 12:47:32)
 * @author: Administrator
 */
public class DictEngine implements IDictEngine {
	IDatabase[] fDatabases;
/**
 * DatabaseFactory constructor comment.
 */
public DictEngine() {
	super();
}
public IAnswer[] define(String db, String word) {
	IAnswer[] ans = defineMatch(db, word, null, true, IDatabase.STRATEGY_NONE);
	Vector v = new Vector(ans.length);
	for (int i = 0; i < ans.length; i++){
		if (ans[i].getDefinition() != null) v.addElement(ans[i]);
	}
	IAnswer[] ret = new IAnswer[v.size()];
	v.copyInto(ret);
	return ret;
}
public static byte[] getData(String fileName) throws IOException {
	FileInputStream fis = null;
	try {
	fis = new FileInputStream(fileName);
	int len = fis.available();
	byte[] b = new byte[len];
	fis.read(b);
	return b;
	} finally {
		try {
			fis.close();
			fis = null;
		} catch (Throwable t) {}
	}
}
/**
 * Insert the method's description here.
 * Creation date: (29.07.01 23:31:38)
 * @return org.dict.IDatabase[]
 */
public IDatabase[] getDatabases() {
	return fDatabases;
}
/**
 * Insert the method's description here.
 * Creation date: (29.07.01 23:31:38)
 * @param newDatabases org.dict.IDatabase[]
 */
public void setDatabases(IDatabase[] newDatabases) {
	fDatabases = newDatabases;
}

/**
 * defineMatch method comment.
 */
public IAnswer[] defineMatch(String db, String word, String pos, boolean define, int strategy) {
	if (pos != null) {
		int idx = Integer.parseInt(pos);
		IDatabase d = findDatabase(db);
		if (d == null) {
			throw new RuntimeException("Database does not exist: "+db);
		}
		return new IAnswer[]{d.defineMatch(idx, define, strategy)};
	}
	if (word == null) return null;
	String s = word.trim();
	if (db.equals("*")) return defineMatchAll(s, define, strategy);
	if (db.equals("!")) return defineMatchAll(s, define, strategy);
	IDatabase d = findDatabase(db);
	if (d == null) {
		throw new RuntimeException("Database does not exist: "+db);
	}
	IAnswer a = d.defineMatch(s, define, strategy);
	return new IAnswer[]{a};
}

IAnswer[] defineMatchAll(String word, boolean define, int strategy) {
	java.util.Vector v = new java.util.Vector();
	IDatabase[] all = getDatabases();
	for (int i = 0; i < all.length; i++){
		IAnswer a = all[i].defineMatch(word, define, strategy);
		v.addElement(a);
	}
	IAnswer[] ret = new IAnswer[v.size()];
	v.copyInto(ret);
	return ret;
}

IAnswer[] defineMatchAny(String word, boolean define, int strategy) {
	IDatabase[] all = getDatabases();
	for (int i = 0; i < all.length; i++){
		IAnswer a = all[i].defineMatch(word, define, strategy);
		if (a.getDefinition() != null) {
			return new IAnswer[]{a};
		}
	}
	return new IAnswer[0];
}

private IDatabase findDatabase(String id) {
	IDatabase[] all = getDatabases();
	for (int i = 0; i < all.length; i++){
		if (all[i].getID().equalsIgnoreCase(id)) {
			return all[i];
		}
	}
	return null;
}

public IAnswer[] match(String db, String word, int strategy) {
	return defineMatch(db, word, null, false, strategy);
}
}
