package org.dict.kernel;

/**
 * Insert the type's description here.
 * Creation date: (10.08.01 20:55:06)
 * @author: Administrator
 */
public interface IAnswer {
/**
 * Insert the method's description here.
 * Creation date: (10.08.01 20:55:40)
 * @return org.dict.IDatabase
 */
IDatabase getDatabase();
String getDefinition();

String getKey();

INeighbor[] getMatches();

int getPosition();
}
