package org.dict.kernel;

/**
 * Insert the type's description here.
 * Creation date: (25.02.2002 17:58:51)
 * @author: 
 */
public interface INeighbor {
String getKey();
int getPosition();
}
