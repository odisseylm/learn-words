package org.dict.server;

import java.net.*;
import java.io.*;
import java.util.*;
import org.dict.kernel.*;
/**
 * Start with: java ...JDictd iniFile<p>
 * For the format of the ini file see DatabaseFactory.
 */
public class JDictd implements Runnable {
	public static final String SERVER_NAME = "Ho Ngoc Duc's DICT server";
	public static final String SERVER_VERSION = "1.2";
	public static final String DICT_PORT = "dict_port";
	public static final String HTTP_PORT = "http_port";
	//private static Properties fProperties = new Properties();
	private static boolean fSilent = Boolean.getBoolean("silent");
	private IDictEngine fEngine;
	private ServerSocket fServerSocket;
	private ServerSocket fHTTPSocket;
public JDictd(ServerSocket dictdSocket, ServerSocket httpSocket, IDictEngine engine) {
	fServerSocket = dictdSocket;
	fHTTPSocket = httpSocket;
	fEngine = engine;
}
public static void listen(String cfg) {
    Properties prop = System.getProperties();
    if (cfg == null || !new File(cfg).exists()) {
        throw new RuntimeException("No configuration file specified");
    }
    IDictEngine engine = DatabaseFactory.getEngine(cfg);
    try {
        int port = Integer.parseInt(prop.getProperty(DICT_PORT, "2628"));
        ServerSocket socket = new ServerSocket(port);
        Runnable r = new JDictd(socket, null, engine);
        new Thread(r, SERVER_NAME).start();
        trace(new Date().toString() + ": JDictd started at " + port);
    } catch (Exception e) {
        System.out.println("Cannot init: " + e);
    }
    try {
        int httpPort = Integer.parseInt(prop.getProperty(HTTP_PORT, "2626"));
        if (httpPort > 0) {
            ServerSocket httpSocket = new ServerSocket(httpPort);
            Runnable httpRunner = new JDictd(null, httpSocket, engine);
            new Thread(httpRunner, SERVER_NAME).start();
            trace(new Date().toString() + ": HTTP server started at " + httpPort);
        } else {
	        trace("HTTP server not started");
        }
    } catch (Exception e) {
        System.out.println("Cannot init: " + e);
        return;
    }
}
public static void log(String msg, String file) {
	if (!fSilent) {
		System.out.println(msg);
		return;
	}
	try {
		RandomAccessFile out = new RandomAccessFile(file, "rw");
		out.seek(out.length());
		out.writeBytes(msg);
		out.writeByte('\n');
		out.close();
	} catch (Throwable t) {
	}
}
public static void main(String args[]) {
	if (args.length == 0) {
		System.out.println("Usage: java ...JDictd configFile");
		System.exit(0);
	}
	listen(args[0]);
}
public void run() {
	if (fServerSocket != null) {
		runRFC2229();
	}
	if (fHTTPSocket != null) {
		runHTTP();
	}
}
protected void runHTTP() {
	try {
		do {
			java.net.Socket s = fHTTPSocket.accept();
			DictHTTPConnection c = new DictHTTPConnection(fEngine, s);
			new Thread(c).start();
		} while (true);
	} catch (IOException e) {
		trace("Error while running: " + e.getMessage());
	}
}
protected void runRFC2229() {
	try {
		do {
			java.net.Socket s = fServerSocket.accept();
			s.setSoTimeout(5000);
			RFC2229 r = new RFC2229(fEngine, s);
			new Thread(r).start();
		} while (true);
	} catch (IOException e) {
		trace("Error while running: " + e.getMessage());
	}
}
static void trace(String s) {
	log(s, "jdictd.log");
}
}
