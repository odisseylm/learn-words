package org.dict.server;

import java.util.StringTokenizer;
import java.util.Vector;
import org.dict.kernel.*;
import java.io.*;
/**
 * Format of the ini file:
 * <pre>
	# All databases
	databases=ev;ve
	# Configuration for ev
	ev.data=anhviet.txt
	ev.index=anhviet.idx
	ev.memoryIndex=true
	ev.comparator=org.dict.vietdict.KeyComparator
	ev.name=English-Vietnamese
	# Configuration for ve
	ve.data=vietanh.txt
	ve.index=vietanh.idx
	ve.memoryIndex=true
	ve.comparator=org.dict.vietdict.KeyComparator
	ev.name=Vietnamese-English
 * </pre>
 */
public class DatabaseFactory {
	static java.util.Hashtable fInstances = new java.util.Hashtable();
	static boolean fSilent = !Boolean.getBoolean("debug");
/**
 * DatabaseFactory constructor comment.
 */
public DatabaseFactory() {
	super();
}
public static Database createDatabase(
    String id,
    File f,
    java.util.Properties p)
    throws Exception {
    // Create database with data file
    String data = getFilename(f, p.getProperty(id + ".data"));
    log("\nCreating database with data file " + data);
    Database ret = null;
    if (data.toLowerCase().endsWith(".dz")) {
        ret = new org.dict.zip.DictZipDatabase();
    } else {
        ret = new FlatDatabase();
    }
    ret.setID(id);
    ret.setDatafile(data);
    String enc = p.getProperty(id + ".encoding", "latin1");
    ret.setEncoding(enc);
    // Init key list
    KeyList kl = null;
    String idx = getFilename(f, p.getProperty(id + ".index"));
    boolean inMemory = !"false".equals(p.getProperty(id + ".memoryIndex"));
    if (inMemory) {
        kl = new MemoryKeyList(idx);
    } else {
        kl = new FileKeyList(idx);
    }
    kl.setEncoding(enc);
    ret.setIndex(kl);
    // Init comparator
    IComparator c = new KeyComparator();
    String comp = p.getProperty(id + ".comparator");
    try {
        if (comp != null) {
            c = (IComparator) Class.forName(comp).newInstance();
        }
    } catch (Throwable t) {
        System.out.println("Cannot init comparator: " + t);
    }
    ret.setComparator(c);
    log("Comparator used for keys: " + c);
    // Init morphological functions
    IMorphAnalyzer ma = null;
    String morphName = p.getProperty(id + ".morph");
    try {
        if (morphName != null) {
            ma = (IMorphAnalyzer) Class.forName(morphName).newInstance();
        }
    } catch (Throwable t) {
        System.out.println("No morphological function available: " + t);
    }
    ret.setMorphAnalyzer(ma);
    log("Morphological functions used: " + ma);
    // Search database for its name if necessary
    String name = p.getProperty(id + ".name");
    if (name == null) {
        String dbName = "00-database-short";
        name = ret.define(dbName);
        if (name == null || !name.startsWith(dbName)) {
            name = id;
        } else {
            name = name.substring(dbName.length()).trim();
        }
    }
    ret.setName(name);
    ret.setSourceLanguage(getLanguage(p.getProperty(id + ".sourceLanguage")));
    ret.setTargetLanguage(getLanguage(p.getProperty(id + ".targetLanguage")));
    log("Database created: " + name);
    return ret;
}
static IDictEngine createEngine(String cfg) {
	java.util.Properties p = new java.util.Properties();
	try {
		InputStream in = new FileInputStream(cfg);
		p.load(in);
		in.close();
	} catch (Throwable t) {
		t.printStackTrace();
	}
	File f = new File(cfg);
	log(new java.util.Date().toString());
	log("\nCreate dictionary engine using configuration "+cfg);
	Vector v1 = getDatabaseNames(cfg);
	String[] dbIDs = new String[v1.size()];
	v1.copyInto(dbIDs);
	DictEngine ret = new DictEngine();
	Vector v = new Vector(dbIDs.length);
	for (int i = 0; i<dbIDs.length; i++){
		if ("false".equals(p.getProperty(dbIDs[i]+".use"))) continue;
		try {
			v.addElement(createDatabase(dbIDs[i], f, p));
		} catch (Exception e) {
			log("Cannot create database "+dbIDs[i]);
			log(e.toString());
		}
	}
	IDatabase[] dbs = new IDatabase[v.size()];
	v.copyInto(dbs);
	ret.setDatabases(dbs);
	log("\nDatabase engine created!");
	fSilent = true;
	return ret;
}
static Vector getDatabaseNames(String cfg) {
    Vector v = new Vector(5);
    try {
        BufferedReader r = new BufferedReader(new FileReader(cfg));
        String s;
        while ((s = r.readLine()) != null) {
            int idx = s.indexOf('.');
            if (idx > 0 && s.indexOf('=', idx) > 0) {
                s = s.substring(0, idx);
                if (!v.contains(s)) {
                    v.addElement(s);
                }
            }
        }
        r.close();
    } catch (Throwable t) {
        t.printStackTrace();
    }
    return v;
}
public static IDictEngine getEngine(String cfg) {
	String s = new File(cfg).getAbsolutePath().toLowerCase();
	IDictEngine ret = (IDictEngine) fInstances.get(s);
	if (ret == null) {
		ret = createEngine(cfg);
		fInstances.put(s, ret);
	}
	return ret;
}
static String getFilename(File cfg, String s) {
	File f = new File(s);
	if (f.isAbsolute()) return s;
	return new File(cfg.getParent(), s).getAbsolutePath();
}
static int getLanguage(String s) {
	if ("fr".equalsIgnoreCase(s)) return IDatabase.LANGUAGE_FRENCH;
	if ("vn".equalsIgnoreCase(s)) return IDatabase.LANGUAGE_VIETNAMESE;
	return IDatabase.LANGUAGE_ENGLISH;
}
static void log(String msg) {
	if (!fSilent) System.out.println(msg);
}
}
