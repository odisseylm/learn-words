package org.dict.server;

import org.dict.kernel.*;
import org.dict.kernel.IDictEngine;
import javax.servlet.http.*;

public class DictServlet extends HttpServlet {
	org.dict.kernel.IDictEngine fEngine;
/**
 * WordNetServlet constructor comment.
 */
public DictServlet() {
	super();
}
/**
 * WordNetServlet constructor comment.
 */
public DictServlet(IDictEngine engine) {
	super();
	fEngine = engine;
}
protected void doGet(HttpServletRequest req, HttpServletResponse res)
	throws javax.servlet.ServletException, java.io.IOException {
	handleRequest(req, res);
}
protected void doPost(HttpServletRequest req, HttpServletResponse res)
	throws javax.servlet.ServletException, java.io.IOException {
	handleRequest(req, res);
}
/**
 * handleRequest method comment.
 */
protected void handleRequest(javax.servlet.http.HttpServletRequest req, javax.servlet.http.HttpServletResponse res) throws javax.servlet.ServletException, java.io.IOException {
	String word = req.getParameter("word");
	String pos = req.getParameter("pos");
	String db = req.getParameter("db");
	if (db == null) {
		db = "*";
	}
	res.setContentType("text/html; charset=UTF-8");
	java.io.PrintWriter out = res.getWriter();
	DictHTMLPrinter p = DictHTMLPrinter.getInstance();
	IAnswer[] answers = null;
	answers = fEngine.defineMatch(db, word, pos, true, IDatabase.STRATEGY_NEAR);
	p.printAnswers(fEngine, answers, out, word, req.getRequestURI());
}
public void init() {
	String cfg = getInitParameter("config");
	String base = getServletContext().getRealPath("/");
	cfg = new java.io.File(base, cfg).getAbsolutePath();
	fEngine = org.dict.server.DatabaseFactory.getEngine(cfg);
}
}
