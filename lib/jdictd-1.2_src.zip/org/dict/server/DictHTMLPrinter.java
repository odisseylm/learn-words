package org.dict.server;

import java.io.*;
import org.dict.kernel.*;
/**
 * Insert the type's description here.
 * Creation date: (24.02.2002 14:44:28)
 * @author: 
 */
public class DictHTMLPrinter {
	private static DictHTMLPrinter fInstance = new DictHTMLPrinter();
/**
 * HTMLFormat constructor comment.
 */
public DictHTMLPrinter() {
	super();
}
public static void appendLink(String s, String base, int pos, StringBuffer sb) {
	sb.append("<a href=\"");
	sb.append(base);
	sb.append(pos);
	sb.append("\">");
	sb.append(s);
	sb.append("</a>");
}
public static void appendLink(String s, String base, StringBuffer sb) {
	sb.append("<a href=\"");
	sb.append(base);
	sb.append(s);
	sb.append("\">");
	sb.append(s);
	sb.append("</a>");
}
public static DictHTMLPrinter getInstance() {
	return fInstance;
}
public static String makeLink(String def, String base) {
	if (def == null) return "";
	String delim = "{}";
	java.util.StringTokenizer st = new java.util.StringTokenizer(def, delim, true);
	StringBuffer sb = new StringBuffer(def.length());
	String s;
	while (st.hasMoreTokens()) {
		s = st.nextToken();
		if (s.equals("}")) {
			continue;
		}
		if (s.equals("{")) {
			String tok = st.nextToken();
			s = removeSpaces(tok);
			if (tok.indexOf('\n') >= 0) {
				sb.append("\n\t");
			}
			appendLink(s, base, sb);
		}
		else {
			sb.append(s);
		}
	}
	return sb.toString();
}
public void printAnswers(IDictEngine e, IAnswer[] answers, PrintWriter out, String word, String uri) throws IOException {
	out.println("<html>");
	out.println("<head><title>");
	if (word != null) {
		out.print(word);
	} else {
		out.print("Dictionary lookup");
	}
	out.println("</title>");
	out.println("<META HTTP-EQUIV=\"Content-Type\" content=\"text/html; charset=UTF-8\">");
	out.println("</head><body>");
	IDatabase[] dbs = e.getDatabases();
	printForm(dbs, out, word, uri);
	if (answers == null) {
		out.println("</body></html>");
		return;
	}
	for (int i = 0; i < answers.length; i++){
		out.print("<h3>Reply from: ");
		out.print(answers[i].getDatabase().getName());
		out.println("</h3>\n");
		String s = answers[i].getDefinition();
		String base = uri+"?db="+answers[i].getDatabase().getID()+"&word=";
		String posBase = uri+"?db="+answers[i].getDatabase().getID()+"&pos=";
		if (s != null) {
			out.println("<pre>");
			String lk = makeLink(s, base);
			out.println(lk);
			out.println("</pre>");
		} else {
			StringBuffer sb = new StringBuffer("Not found. Maybe you mean: \n");
			INeighbor[] neighbors = answers[i].getMatches();
			for (int k = 0; k < neighbors.length; k++){
				appendLink(neighbors[k].getKey(), posBase, neighbors[k].getPosition(), sb);
				sb.append(" | \n");
			}
			out.println(sb);
		}
	}
	out.println("</body></html>");
}
private void printForm(IDatabase[] dbs, PrintWriter out, String word, String uri) throws IOException {
	String wd = word == null ? "" : word;
	out.println("Please enter the word or phrase to look for!<p>");
	out.println("<FORM METHOD=GET action=\""+uri+"\">");
	out.println("<b>Word:</b> <INPUT SIZE=15 NAME=\"word\" VALUE=\""+wd+"\">");
	out.println("<b>Database:</b> <select name=\"db\">");
	out.println("  <option value=\"*\" selected>Any");
	out.println("  <option value=\"!\">First match");
	for (int i = 0; i < dbs.length; i++){
		String db = dbs[i].getName();
		out.println("  <option value=\""+dbs[i].getID()+"\">"+db);
	}
	out.println("</select>");
	out.println("<b><input type=\"SUBMIT\"></b>");
	out.println("</FORM>");
}
public static String removeSpaces(String s) {
	java.util.StringTokenizer st = new java.util.StringTokenizer(s, " \t\n\r\f", false);
	StringBuffer sb = new StringBuffer(s.length());
	while (st.hasMoreTokens()) {
		sb.append(st.nextToken()).append(' ');
	}
	return sb.toString().trim();
}
}
