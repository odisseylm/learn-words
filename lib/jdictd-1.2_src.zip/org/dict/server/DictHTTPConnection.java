package org.dict.server;

import java.net.*;
import java.io.*;
import java.util.*;
import org.dict.kernel.*;

public class DictHTTPConnection implements Runnable {
    private IDictEngine fEngine;
    private Socket theConnection;
    public DictHTTPConnection(IDictEngine e, Socket s) {
	    fEngine = e;
	    theConnection = s;
    }
	public static String decode(String s) 
	{
		ByteArrayOutputStream out = new ByteArrayOutputStream(s.length());
		
		for (int i = 0; i < s.length(); i++) 
		{
			char c = s.charAt(i);
			if (c == '+') 
			{
				out.write(' ');
			}
			else if (c == '%') 
			{
				int c1 = Character.digit(s.charAt(++i), 16);
				int c2 = Character.digit(s.charAt(++i), 16);
				out.write((char) (c1 * 16 + c2));
			}
			else 
			{
				out.write(c);
			}
		} // end for
		
		return out.toString();
		
	}
	public static Properties parseQuery(String s)
	{
		return parseQuery(s, "&", "=");
	}
	public static Properties parseQuery(String s, String delim, String rel)
	{
		java.util.Properties result = new java.util.Properties();
		StringTokenizer st = new StringTokenizer(s, delim);
		String current, key, value;
		int sep = 0;
		while (st.hasMoreTokens()) 
		{
			current = st.nextToken();
			sep = current.indexOf(rel);
			if (sep == -1) sep = 0;
			key = decode(current.substring(0, sep));
			value = decode(current.substring(sep+1));
			result.put(key,value);
			//System.out.println(key+" = "+value);
		}
		return result;
	}
	public void run() 
	{
		String method = "";
		String file = "";
		String version = "";
		
		try 
		{
			PrintWriter os = new PrintWriter(new OutputStreamWriter(theConnection.getOutputStream(), "UTF8"));
			BufferedReader is = 
				new BufferedReader(new InputStreamReader(theConnection.getInputStream()));
			String get = is.readLine();
			if (get == null) return;
			StringTokenizer st = new StringTokenizer(get);
			method = st.nextToken();
			if (method.equals("GET")) 
			{
				file = st.nextToken();
				
				if (st.hasMoreTokens()) 
				{
					version = st.nextToken();
				}
				// loop through the rest of the input lines 
				while ((get = is.readLine()) != null) 
				{
					if (get.trim().equals("")) break;        
				}
				
				serveGET(os, file, version);
			}
			os.close();
		}
		catch (IOException e) // Ignore I/O exceptions 
		{			
		}
		
		// After the data have been sent, close the connection
		try 
		{
			theConnection.close();
		}
		catch (IOException e) 
		{
		}
	}
protected void serveGET(PrintWriter os, String file, String version)
    throws IOException {
    DictHTMLPrinter p = DictHTMLPrinter.getInstance();
    String query = file;
    int idx = query.indexOf('?');
    if (idx == -1) {
        query += "?";
        idx = 0;
    }
    try {
        String uri = query.substring(0, idx);
        String param = query.substring(idx + 1);
        Properties paramDict = parseQuery(param);
        String word = paramDict.getProperty("word");
        String db = paramDict.getProperty("db", "*");
        String pos = paramDict.getProperty("pos");
		os.print("HTTP/1.0 200 OK\r\nContent-type: text/html\r\n\r\n");
        IAnswer[] answers = fEngine.defineMatch(db, word, pos, true, IDatabase.STRATEGY_NEAR);
        p.printAnswers(fEngine, answers, os, word, uri);
    } catch (Throwable t) {
		os.println("<pre>");
        t.printStackTrace(os);
		os.println("</pre>");
    }
}
}
